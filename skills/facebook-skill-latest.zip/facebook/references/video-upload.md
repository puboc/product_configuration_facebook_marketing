# Video Upload Guide

## 1) Choose the upload mode
- Use `POST /{page-id}/videos` with `file_url` when the video is already hosted at a stable public URL.
- Use `POST /{page-id}/videos` with `source` (multipart binary upload) when the video file is local.
- Prefer a resumable upload flow for larger or less reliable network transfers.

## 2) Direct Page video publish
- Endpoint: `POST /{page-id}/videos`
- Common fields:
  - `file_url` or `source`
  - `title`
  - `description`
  - `published`
  - `thumb`
  - `scheduled_publish_time` when publishing later

## 3) Resumable upload workflow
Use resumable upload when the file is large, uploads may be interrupted, or you want safer retries.

High-level flow:
1. Create an upload session.
2. Transfer bytes and track the returned offset.
3. Resume from the last confirmed offset if interrupted.
4. Finish by publishing the uploaded file handle to the Page video endpoint.

Operational note:
- Exact resumable parameters can vary by Graph API version. Pin the API version and verify the current Meta docs before implementing the final request shape.

## 4) Poll video processing state
After upload, the video may need processing before it is fully available.

Useful read:
- `GET /{video-id}?fields=id,status,permalink_url,updated_time`

Use polling with backoff rather than tight loops.

## 5) Reliability guidance
- Prefer public `file_url` only when the source file is stable and fast to fetch.
- Prefer multipart `source` for local files you control.
- Prefer resumable upload for larger files and unreliable networks.
- Treat upload and publish as separate steps when building production automation.
- Log only video IDs, status, and timestamps; never log tokens.
