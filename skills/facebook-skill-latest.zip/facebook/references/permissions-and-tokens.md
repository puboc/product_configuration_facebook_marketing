# Permissions and Tokens

## 1) Token types
- User access token (granted via OAuth).
- Page access token (used for Page content actions).

## 2) Common Page permissions
- `pages_manage_posts` (publish and edit Page posts, including photos and videos)
- `pages_read_engagement` (read Page content and engagement)
- `pages_manage_engagement` (moderate comments)
- `pages_show_list` (list Pages the user manages)

## 3) Recommended flow (high level)
- Obtain a user token with the required scopes.
- Call `/me/accounts` to get the Page access token for the target Page.
- Use the Page token for Page publishing and comment moderation.

## 4) App review and environment guidance
- Expect permission review for production use.
- Confirm that the app mode and user/app roles allow the intended test flow.
- Verify the user actually has the needed Page tasks/roles before debugging the request payload.

## 5) Operational guidance
- Use least privilege.
- Store tokens securely and rotate when possible.
- Prefer bearer headers instead of query-string tokens.
- Keep user-token acquisition separate from publish-time Page actions.
