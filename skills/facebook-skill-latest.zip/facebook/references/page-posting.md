# Page Posting Guide

## 1) Create a text or link post
- Endpoint: `POST /{page-id}/feed`
- Common fields:
  - `message` (text content)
  - `link` (URL to attach)
  - `published` (true/false)
  - `scheduled_publish_time` (unix timestamp)

## 2) Create a photo post
- Endpoint: `POST /{page-id}/photos`
- Common fields:
  - `url` or `source` (binary upload)
  - `caption`
  - `published`
  - `scheduled_publish_time` when scheduling is supported by the chosen flow

## 3) Create a video post
- Endpoint: `POST /{page-id}/videos`
- Common fields:
  - `file_url` or `source`
  - `title`
  - `description`
  - `published`
  - `scheduled_publish_time`

Read `video-upload.md` when the video file is large, local, or likely to require resumable upload.

## 4) Read posts
- Endpoint: `GET /{page-id}/posts`
- Common fields/params:
  - `fields` (e.g. `id,message,created_time,permalink_url`)
  - `limit`, `since`, `until`

## 5) Read videos directly
- Endpoint: `GET /{page-id}/videos`
- Useful fields:
  - `id`
  - `title`
  - `description`
  - `status`
  - `permalink_url`
  - `updated_time`

## 6) Update or delete
- Update post: `POST /{post-id}` (fields you want to change)
- Delete post: `DELETE /{post-id}`

## Notes
- Page access token required for publish actions.
- Keep messages concise and avoid frequent edits.
- Treat upload completion and video processing completion as different states.
- Prefer pinned API versions and explicit polling for video readiness.
