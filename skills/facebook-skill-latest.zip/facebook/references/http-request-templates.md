# HTTP Request Templates (Graph API)

## Request style
- Prefer `Authorization: Bearer <PAGE_ACCESS_TOKEN>` over placing tokens in the query string.
- Pin a versioned base URL such as `https://graph.facebook.com/v23.0`.

## Create Page post
POST `/{page-id}/feed`
```json
{
  "message": "Hello from the bot",
  "published": true
}
```

Example:
```bash
curl -X POST "https://graph.facebook.com/v23.0/${PAGE_ID}/feed" \
  -H "Authorization: Bearer ${PAGE_ACCESS_TOKEN}" \
  -d "message=Hello from the bot" \
  -d "published=true"
```

## Schedule Page post
POST `/{page-id}/feed`
```json
{
  "message": "Scheduled post",
  "published": false,
  "scheduled_publish_time": 1735689600
}
```

## Create photo post
POST `/{page-id}/photos`
```json
{
  "url": "https://example.com/image.jpg",
  "caption": "Caption",
  "published": true
}
```

## Create video post from hosted URL
POST `/{page-id}/videos`
```json
{
  "file_url": "https://example.com/video.mp4",
  "title": "Launch clip",
  "description": "Uploaded by automation",
  "published": true
}
```

Example:
```bash
curl -X POST "https://graph.facebook.com/v23.0/${PAGE_ID}/videos" \
  -H "Authorization: Bearer ${PAGE_ACCESS_TOKEN}" \
  -d "file_url=https://example.com/video.mp4" \
  -d "title=Launch clip" \
  -d "description=Uploaded by automation" \
  -d "published=true"
```

## Create video post from local file
POST `/{page-id}/videos`

Example:
```bash
curl -X POST "https://graph.facebook.com/v23.0/${PAGE_ID}/videos" \
  -H "Authorization: Bearer ${PAGE_ACCESS_TOKEN}" \
  -F "source=@/absolute/path/video.mp4" \
  -F "title=Launch clip" \
  -F "description=Uploaded by automation" \
  -F "published=true"
```

## Poll uploaded video status
GET `/{video-id}?fields=id,status,permalink_url,updated_time`

Example:
```bash
curl "https://graph.facebook.com/v23.0/${VIDEO_ID}?fields=id,status,permalink_url,updated_time" \
  -H "Authorization: Bearer ${PAGE_ACCESS_TOKEN}"
```

## List posts
GET `/{page-id}/posts?fields=id,message,created_time,permalink_url&limit=5`

## Add comment
POST `/{post-id}/comments`
```json
{
  "message": "Thanks for your feedback!"
}
```

## Hide comment
POST `/{comment-id}`
```json
{
  "is_hidden": true
}
```

## Delete comment
DELETE `/{comment-id}`
