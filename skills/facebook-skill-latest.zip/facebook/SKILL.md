---
name: facebook
description: OpenClaw skill for Facebook Graph API workflows focused on Facebook Pages posting, photo/video publishing, scheduled posts, comments, moderation, webhooks, and Page management using direct HTTPS requests. Use when building or reviewing Page automation with Graph API calls rather than SDKs.
---

# Facebook Graph API Skill (Advanced)

## Purpose
Provide a production-oriented guide for building Facebook Graph API workflows for Pages: publishing text posts, photos, and videos; managing comments; and operating Page content safely using direct HTTPS calls.

## Best fit
- You need Page posting, comment, moderation, or webhook workflows.
- You need direct Graph API request shapes for text, photo, or video publishing.
- You want a professional command design and safe operational guidance.
- You prefer direct HTTP requests rather than SDKs.

## Not a fit
- You need advanced ads or marketing APIs.
- You must use complex browser-based OAuth flows.
- You need a fully implemented SDK or ready-to-run service in this skill itself.

## Quick orientation
- Read `references/graph-api-overview.md` for base URLs, versions, and request patterns.
- Read `references/page-posting.md` for Page publishing workflows and fields.
- Read `references/video-upload.md` when the workflow includes Page video upload or post-processing checks.
- Read `references/comments-moderation.md` for comment actions and moderation flows.
- Read `references/permissions-and-tokens.md` for access types, scopes, and app review guidance.
- Read `references/webhooks.md` for subscriptions and verification steps.
- Read `references/http-request-templates.md` for concrete HTTP request payloads and curl examples.
- Use `scripts/exchange-long-lived-user-token.sh` to convert a short-lived user token into a long-lived user token.
- Use `scripts/check-token.sh` to inspect current token validity, scopes, and expiry metadata.
- Use `scripts/get-page-token.sh` to resolve the current Page access token from a user token.
- Use `scripts/post-text.sh` and `scripts/post-video.sh` for deterministic publish flows.
- Use `scripts/create-campaign.sh` to create a paused campaign with retries for `special_ad_categories` encoding quirks.
- Use `scripts/create-ad-from-post.sh` to turn an existing Page post or video post into an ad under an existing ad set when campaign creation is blocked.

## Required inputs
- Facebook App ID and App Secret.
- Target Page ID(s).
- Token strategy: user token → Page access token.
- Required permissions and review status.
- API version pin and publishing behavior required by the workflow.

## Expected output
- A clear Page workflow plan, permissions checklist, request templates, operational guardrails, and reusable script-based execution paths.

## Script conventions
- Prefer an env file that provides `APP_ID`, `APP_SECRET`, `PAGE_ID`, `AD_ACCOUNT_ID`, and one of `TOKEN` or `LONG_LIVED_USER_TOKEN`.
- Treat `TOKEN` as a user token input, not as a cached Page token.
- Write a cached `PAGE_ACCESS_TOKEN` only when you control the env file and want faster repeated posts.
- Re-resolve the Page token from a valid user token when cached credentials look stale.
- Keep scripts non-interactive and JSON-producing so they compose well with other automation.
- Expect account-specific Marketing API quirks: if campaign creation fails but the account already has a working campaign/ad set, create the creative and ad under the existing structure instead of blocking on perfect campaign automation.

## Operational notes
- Use least-privilege permissions.
- Pin a Graph API version for stability.
- Handle rate limits and retries.
- Poll long-running video processing with backoff.
- Log minimal identifiers only.

## Security notes
- Never log tokens or app secrets.
- Validate webhook signatures.
- Keep access tokens out of URLs when a bearer header is available.
