#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
PAGE_ID_INPUT=""
USER_TOKEN_INPUT=""
WRITE_ENV=0
PRINT_TOKEN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --page-id) PAGE_ID_INPUT="$2"; shift 2 ;;
    --user-token) USER_TOKEN_INPUT="$2"; shift 2 ;;
    --write-env) WRITE_ENV=1; shift ;;
    --print-token) PRINT_TOKEN=1; shift ;;
    -h|--help)
      cat <<'EOF'
Usage: get-page-token.sh [--env path] [--page-id id] [--user-token token] [--write-env] [--print-token]

Resolve the target page from /me/accounts and return its page access token.
User token selection order:
  --user-token
  USER_TOKEN
  LONG_LIVED_USER_TOKEN
  TOKEN
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
PAGE_ID_INPUT="${PAGE_ID_INPUT:-${PAGE_ID:-}}"
USER_TOKEN_INPUT="${USER_TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$PAGE_ID_INPUT" ]]; then
  echo "Missing PAGE_ID" >&2
  exit 1
fi
if [[ -z "$USER_TOKEN_INPUT" ]]; then
  echo "Missing user token" >&2
  exit 1
fi
RESP=$(api_get "${GRAPH_BASE}/me/accounts?fields=id,name,access_token,tasks" "$USER_TOKEN_INPUT")
python3 - "$RESP" "$PAGE_ID_INPUT" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
page_id = sys.argv[2]
if 'error' in obj:
    e = obj['error']
    print(json.dumps({'ok': False, 'message': e.get('message'), 'code': e.get('code'), 'type': e.get('type')}, ensure_ascii=False))
    raise SystemExit(1)
for page in obj.get('data', []):
    if page.get('id') == page_id:
        print(json.dumps({'ok': True, 'page_id': page.get('id'), 'name': page.get('name'), 'tasks': page.get('tasks', []), 'has_access_token': bool(page.get('access_token'))}, ensure_ascii=False))
        raise SystemExit(0)
print(json.dumps({'ok': False, 'message': 'PAGE_ID not found in /me/accounts', 'page_id': page_id}, ensure_ascii=False))
raise SystemExit(1)
PY
ACCESS_TOKEN=$(python3 - "$RESP" "$PAGE_ID_INPUT" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
page_id = sys.argv[2]
for page in obj.get('data', []):
    if page.get('id') == page_id:
        print(page.get('access_token', ''))
        break
PY
)
if [[ -z "$ACCESS_TOKEN" ]]; then
  exit 1
fi
if [[ "$WRITE_ENV" -eq 1 ]]; then
  if [[ -z "$ENV_FILE" ]]; then
    echo "--write-env requires --env" >&2
    exit 1
  fi
  update_env_value "$ENV_FILE" "PAGE_ACCESS_TOKEN" "$ACCESS_TOKEN"
fi
if [[ "$PRINT_TOKEN" -eq 1 ]]; then
  printf '%s\n' "$ACCESS_TOKEN"
fi
