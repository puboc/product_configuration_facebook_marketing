#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
USER_TOKEN_INPUT=""
NAME=""
OBJECTIVE="OUTCOME_ENGAGEMENT"
STATUS="PAUSED"
BUYING_TYPE="AUCTION"
SPECIAL_AD_CATEGORIES_INPUT="NONE"
IS_ADSET_BUDGET_SHARING_ENABLED="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --user-token) USER_TOKEN_INPUT="$2"; shift 2 ;;
    --name) NAME="$2"; shift 2 ;;
    --objective) OBJECTIVE="$2"; shift 2 ;;
    --status) STATUS="$2"; shift 2 ;;
    --buying-type) BUYING_TYPE="$2"; shift 2 ;;
    --special-ad-categories) SPECIAL_AD_CATEGORIES_INPUT="$2"; shift 2 ;;
    --is-adset-budget-sharing-enabled) IS_ADSET_BUDGET_SHARING_ENABLED="$2"; shift 2 ;;
    -h|--help)
      cat <<'EOF'
Usage: create-campaign.sh --name "Campaign name" [--env path] [--user-token token]
                         [--objective OUTCOME_ENGAGEMENT] [--status PAUSED]
                         [--buying-type AUCTION] [--special-ad-categories NONE]
                         [--is-adset-budget-sharing-enabled false]

Create a Facebook Ads campaign under AD_ACCOUNT_ID.
The script retries several special_ad_categories encodings because Meta often rejects one form while accepting another.
Required env vars:
  APP_ID, APP_SECRET, AD_ACCOUNT_ID
Token selection order:
  --user-token
  USER_TOKEN
  LONG_LIVED_USER_TOKEN
  TOKEN
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
require_vars APP_ID APP_SECRET AD_ACCOUNT_ID
USER_TOKEN_INPUT="${USER_TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$USER_TOKEN_INPUT" ]]; then
  echo "Missing user token" >&2
  exit 1
fi
if [[ -z "$NAME" ]]; then
  echo "Missing --name" >&2
  exit 1
fi
AD_ID="$AD_ACCOUNT_ID"
case "$AD_ID" in act_*) ;; *) AD_ID="act_${AD_ID}" ;; esac

run_attempt() {
  local label="$1"
  shift
  local resp
  resp=$(curl -sS -X POST "${GRAPH_BASE}/${AD_ID}/campaigns" -H "Authorization: Bearer ${USER_TOKEN_INPUT}" "$@")
  python3 - "$label" "$resp" <<'PY'
import json, sys
label = sys.argv[1]
obj = json.loads(sys.argv[2])
if 'error' in obj:
    e = obj['error']
    print(json.dumps({
        'ok': False,
        'attempt': label,
        'message': e.get('message'),
        'code': e.get('code'),
        'type': e.get('type'),
        'error_subcode': e.get('error_subcode'),
        'error_user_title': e.get('error_user_title'),
        'error_user_msg': e.get('error_user_msg'),
    }, ensure_ascii=False))
    raise SystemExit(1)
print(json.dumps({'ok': True, 'attempt': label, 'id': obj.get('id')}, ensure_ascii=False))
PY
}

COMMON=(
  --data-urlencode "name=${NAME}"
  --data-urlencode "objective=${OBJECTIVE}"
  --data-urlencode "status=${STATUS}"
  --data-urlencode "buying_type=${BUYING_TYPE}"
  --data-urlencode "is_adset_budget_sharing_enabled=${IS_ADSET_BUDGET_SHARING_ENABLED}"
)

if [[ "$SPECIAL_AD_CATEGORIES_INPUT" == "NONE" ]]; then
  ATTEMPTS=(
    "json-none|special_ad_categories=[\"NONE\"]"
    "scalar-none|special_ad_categories=NONE"
    "empty-array|special_ad_categories=[]"
    "indexed-none|special_ad_categories[0]=NONE"
  )
else
  ATTEMPTS=("custom|special_ad_categories=${SPECIAL_AD_CATEGORIES_INPUT}")
fi

LAST_ERROR=0
for entry in "${ATTEMPTS[@]}"; do
  label="${entry%%|*}"
  field="${entry#*|}"
  if run_attempt "$label" "${COMMON[@]}" --data-urlencode "$field"; then
    exit 0
  else
    LAST_ERROR=$?
  fi
done
exit "$LAST_ERROR"
