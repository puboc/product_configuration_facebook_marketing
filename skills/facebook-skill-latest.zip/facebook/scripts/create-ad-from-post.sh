#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
USER_TOKEN_INPUT=""
ADSET_ID=""
POST_ID=""
CREATIVE_NAME=""
AD_NAME=""
STATUS="PAUSED"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --user-token) USER_TOKEN_INPUT="$2"; shift 2 ;;
    --adset-id) ADSET_ID="$2"; shift 2 ;;
    --post-id) POST_ID="$2"; shift 2 ;;
    --creative-name) CREATIVE_NAME="$2"; shift 2 ;;
    --ad-name) AD_NAME="$2"; shift 2 ;;
    --status) STATUS="$2"; shift 2 ;;
    -h|--help)
      cat <<'EOF'
Usage: create-ad-from-post.sh --adset-id <id> --post-id <page_post_id> [--env path] [--user-token token]
                              [--creative-name text] [--ad-name text] [--status PAUSED]

Create an ad creative from an existing Page post or video post, then create an ad under an existing ad set.
This is useful when campaign creation is blocked but the account already has a working campaign/ad set structure.
Required env vars:
  AD_ACCOUNT_ID
Token selection order:
  --user-token
  USER_TOKEN
  LONG_LIVED_USER_TOKEN
  TOKEN
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
require_vars AD_ACCOUNT_ID
USER_TOKEN_INPUT="${USER_TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$USER_TOKEN_INPUT" ]]; then
  echo "Missing user token" >&2
  exit 1
fi
if [[ -z "$ADSET_ID" || -z "$POST_ID" ]]; then
  echo "Missing --adset-id or --post-id" >&2
  exit 1
fi
AD_ID="$AD_ACCOUNT_ID"
case "$AD_ID" in act_*) ;; *) AD_ID="act_${AD_ID}" ;; esac
STAMP="$(date -u '+%Y-%m-%d %H:%M:%S UTC')"
CREATIVE_NAME="${CREATIVE_NAME:-Creative ${STAMP}}"
AD_NAME="${AD_NAME:-Ad ${STAMP}}"

CREATIVE=$(curl -sS -X POST "${GRAPH_BASE}/${AD_ID}/adcreatives" \
  -H "Authorization: Bearer ${USER_TOKEN_INPUT}" \
  -F "name=${CREATIVE_NAME}" \
  -F "object_story_id=${POST_ID}")
python3 - "$CREATIVE" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
if 'error' in obj:
    e = obj['error']
    print(json.dumps({'ok': False, 'stage': 'creative', 'message': e.get('message'), 'code': e.get('code'), 'type': e.get('type'), 'error_subcode': e.get('error_subcode'), 'error_user_title': e.get('error_user_title'), 'error_user_msg': e.get('error_user_msg')}, ensure_ascii=False))
    raise SystemExit(1)
print(json.dumps({'ok': True, 'stage': 'creative', 'id': obj.get('id')}, ensure_ascii=False))
PY
CREATIVE_ID=$(python3 - "$CREATIVE" <<'PY'
import json, sys
print(json.loads(sys.argv[1]).get('id', ''))
PY
)
AD=$(curl -sS -X POST "${GRAPH_BASE}/${AD_ID}/ads" \
  -H "Authorization: Bearer ${USER_TOKEN_INPUT}" \
  -F "name=${AD_NAME}" \
  -F "adset_id=${ADSET_ID}" \
  -F "status=${STATUS}" \
  -F "creative={\"creative_id\":\"${CREATIVE_ID}\"}")
python3 - "$AD" "$CREATIVE_ID" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
creative_id = sys.argv[2]
if 'error' in obj:
    e = obj['error']
    print(json.dumps({'ok': False, 'stage': 'ad', 'creative_id': creative_id, 'message': e.get('message'), 'code': e.get('code'), 'type': e.get('type'), 'error_subcode': e.get('error_subcode'), 'error_user_title': e.get('error_user_title'), 'error_user_msg': e.get('error_user_msg')}, ensure_ascii=False))
    raise SystemExit(1)
print(json.dumps({'ok': True, 'stage': 'ad', 'creative_id': creative_id, 'id': obj.get('id')}, ensure_ascii=False))
PY
