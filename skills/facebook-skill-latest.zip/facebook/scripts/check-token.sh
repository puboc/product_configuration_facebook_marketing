#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
TOKEN_INPUT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --token) TOKEN_INPUT="$2"; shift 2 ;;
    -h|--help)
      cat <<'EOF'
Usage: check-token.sh [--env path] [--token token]

Load APP_ID and APP_SECRET, then call /debug_token for the chosen user token.
Token selection order:
  --token
  USER_TOKEN
  LONG_LIVED_USER_TOKEN
  TOKEN
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
require_vars APP_ID APP_SECRET
TOKEN_INPUT="${TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$TOKEN_INPUT" ]]; then
  echo "Missing token input" >&2
  exit 1
fi
APP_TOKEN="${APP_ID}|${APP_SECRET}"
RESP=$(curl -sS "https://graph.facebook.com/debug_token?input_token=${TOKEN_INPUT}&access_token=${APP_TOKEN}")
python3 - "$RESP" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
d = obj.get('data', {})
out = {
    'is_valid': d.get('is_valid'),
    'type': d.get('type'),
    'application': d.get('application'),
    'scopes': d.get('scopes'),
    'granular_scopes': d.get('granular_scopes'),
    'expires_at': d.get('expires_at'),
    'data_access_expires_at': d.get('data_access_expires_at'),
    'user_id': d.get('user_id'),
}
print(json.dumps(out, ensure_ascii=False))
PY
