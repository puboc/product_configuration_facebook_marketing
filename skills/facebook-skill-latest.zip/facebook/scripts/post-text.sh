#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
PAGE_ID_INPUT=""
PAGE_TOKEN_INPUT=""
USER_TOKEN_INPUT=""
MESSAGE=""
PUBLISHED="true"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --page-id) PAGE_ID_INPUT="$2"; shift 2 ;;
    --page-token) PAGE_TOKEN_INPUT="$2"; shift 2 ;;
    --user-token) USER_TOKEN_INPUT="$2"; shift 2 ;;
    --message) MESSAGE="$2"; shift 2 ;;
    --published) PUBLISHED="$2"; shift 2 ;;
    -h|--help)
      cat <<'EOF'
Usage: post-text.sh --message "text" [--env path] [--page-id id] [--page-token token] [--user-token token] [--published true|false]

Post a text-only message to a Facebook Page feed.
If --page-token is omitted, resolve the page token from the selected user token.
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
PAGE_ID_INPUT="${PAGE_ID_INPUT:-${PAGE_ID:-}}"
PAGE_TOKEN_INPUT="${PAGE_TOKEN_INPUT:-${PAGE_ACCESS_TOKEN:-}}"
USER_TOKEN_INPUT="${USER_TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$PAGE_ID_INPUT" ]]; then
  echo "Missing PAGE_ID" >&2
  exit 1
fi
if [[ -z "$MESSAGE" ]]; then
  echo "Missing --message" >&2
  exit 1
fi
if [[ -z "$PAGE_TOKEN_INPUT" ]]; then
  if [[ -z "$USER_TOKEN_INPUT" ]]; then
    echo "Missing page token and user token" >&2
    exit 1
  fi
  ACCTS=$(api_get "${GRAPH_BASE}/me/accounts?fields=id,name,access_token,tasks" "$USER_TOKEN_INPUT")
  PAGE_TOKEN_INPUT=$(python3 - "$ACCTS" "$PAGE_ID_INPUT" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
page_id = sys.argv[2]
for page in obj.get('data', []):
    if page.get('id') == page_id:
        print(page.get('access_token', ''))
        break
PY
)
fi
if [[ -z "$PAGE_TOKEN_INPUT" ]]; then
  echo "Unable to resolve page token" >&2
  exit 1
fi
RESP=$(api_post_form "${GRAPH_BASE}/${PAGE_ID_INPUT}/feed" "$PAGE_TOKEN_INPUT" \
  --data-urlencode "message=${MESSAGE}" \
  -d "published=${PUBLISHED}")
python3 - "$RESP" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
if 'error' in obj:
    e = obj['error']
    print(json.dumps({'ok': False, 'message': e.get('message'), 'code': e.get('code'), 'type': e.get('type'), 'error_subcode': e.get('error_subcode')}, ensure_ascii=False))
else:
    print(json.dumps({'ok': True, 'id': obj.get('id')}, ensure_ascii=False))
PY
