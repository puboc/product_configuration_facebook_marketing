#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=./common.sh
. "$SCRIPT_DIR/common.sh"

ENV_FILE=""
TOKEN_INPUT=""
WRITE_ENV=0
PRINT_TOKEN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILE="$2"; shift 2 ;;
    --token) TOKEN_INPUT="$2"; shift 2 ;;
    --write-env) WRITE_ENV=1; shift ;;
    --print-token) PRINT_TOKEN=1; shift ;;
    -h|--help)
      cat <<'EOF'
Usage: exchange-long-lived-user-token.sh [--env path] [--token token] [--write-env] [--print-token]

Exchange a short-lived Facebook user token for a long-lived user token.
Requires APP_ID and APP_SECRET.
If --write-env is set, write LONG_LIVED_USER_TOKEN into the env file.
EOF
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

load_env_file "$ENV_FILE"
require_vars APP_ID APP_SECRET
TOKEN_INPUT="${TOKEN_INPUT:-$(pick_user_token)}"
if [[ -z "$TOKEN_INPUT" ]]; then
  echo "Missing token input" >&2
  exit 1
fi
RESP=$(curl -sS "${GRAPH_BASE}/oauth/access_token?grant_type=fb_exchange_token&client_id=${APP_ID}&client_secret=${APP_SECRET}&fb_exchange_token=${TOKEN_INPUT}")
python3 - "$RESP" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
if 'error' in obj:
    e = obj['error']
    print(json.dumps({'ok': False, 'message': e.get('message'), 'code': e.get('code'), 'type': e.get('type'), 'error_subcode': e.get('error_subcode')}, ensure_ascii=False))
else:
    print(json.dumps({'ok': True, 'token_type': obj.get('token_type'), 'expires_in': obj.get('expires_in'), 'has_access_token': bool(obj.get('access_token'))}, ensure_ascii=False))
PY
ACCESS_TOKEN=$(python3 - "$RESP" <<'PY'
import json, sys
print(json.loads(sys.argv[1]).get('access_token', ''))
PY
)
if [[ -z "$ACCESS_TOKEN" ]]; then
  exit 1
fi
if [[ "$WRITE_ENV" -eq 1 ]]; then
  if [[ -z "$ENV_FILE" ]]; then
    echo "--write-env requires --env" >&2
    exit 1
  fi
  update_env_value "$ENV_FILE" "LONG_LIVED_USER_TOKEN" "$ACCESS_TOKEN"
fi
if [[ "$PRINT_TOKEN" -eq 1 ]]; then
  printf '%s\n' "$ACCESS_TOKEN"
fi
