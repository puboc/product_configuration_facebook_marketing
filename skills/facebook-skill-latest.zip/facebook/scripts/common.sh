#!/usr/bin/env bash
set -euo pipefail

GRAPH_VERSION="${GRAPH_VERSION:-v23.0}"
GRAPH_BASE="https://graph.facebook.com/${GRAPH_VERSION}"

usage_common() {
  cat <<'EOF'
Common environment variables:
  APP_ID, APP_SECRET
  PAGE_ID
  TOKEN                  short-lived or user token
  LONG_LIVED_USER_TOKEN  optional preferred user token
  PAGE_ACCESS_TOKEN      optional cached page token

Most scripts accept:
  --env <path>           load variables from an env file
EOF
}

load_env_file() {
  local env_file="${1:-}"
  if [[ -n "$env_file" ]]; then
    if [[ ! -f "$env_file" ]]; then
      echo "Env file not found: $env_file" >&2
      exit 1
    fi
    set -a
    # shellcheck disable=SC1090
    . "$env_file"
    set +a
  fi
}

require_vars() {
  local missing=0
  for var in "$@"; do
    if [[ -z "${!var:-}" ]]; then
      echo "Missing required variable: $var" >&2
      missing=1
    fi
  done
  if [[ "$missing" -ne 0 ]]; then
    exit 1
  fi
}

pick_user_token() {
  if [[ -n "${USER_TOKEN:-}" ]]; then
    printf '%s' "$USER_TOKEN"
  elif [[ -n "${LONG_LIVED_USER_TOKEN:-}" ]]; then
    printf '%s' "$LONG_LIVED_USER_TOKEN"
  elif [[ -n "${TOKEN:-}" ]]; then
    printf '%s' "$TOKEN"
  else
    printf ''
  fi
}

json_extract() {
  local payload="$1"
  local expr="$2"
  python3 - "$payload" "$expr" <<'PY'
import json, sys
payload = json.loads(sys.argv[1])
expr = sys.argv[2]
cur = payload
for part in expr.split('.'):
    if isinstance(cur, dict):
        cur = cur.get(part)
    else:
        cur = None
        break
if cur is None:
    print("")
elif isinstance(cur, (dict, list)):
    print(json.dumps(cur, ensure_ascii=False))
else:
    print(cur)
PY
}

print_json_summary() {
  local payload="$1"
  python3 - "$payload" <<'PY'
import json, sys
obj = json.loads(sys.argv[1])
print(json.dumps(obj, ensure_ascii=False))
PY
}

update_env_value() {
  local env_file="$1"
  local key="$2"
  local value="$3"
  python3 - "$env_file" "$key" "$value" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
key = sys.argv[2]
value = sys.argv[3]
lines = path.read_text().splitlines() if path.exists() else []
out = []
updated = False
for line in lines:
    if line.startswith(f"{key}="):
        out.append(f"{key}={value}")
        updated = True
    else:
        out.append(line)
if not updated:
    out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY
}

api_get() {
  local url="$1"
  local bearer="$2"
  curl -sS "$url" -H "Authorization: Bearer ${bearer}"
}

api_post_form() {
  local url="$1"
  local bearer="$2"
  shift 2
  curl -sS -X POST "$url" -H "Authorization: Bearer ${bearer}" "$@"
}
